#ifndef TPPARTIE2_H
#define TPPARTIE2_H

#include <iostream>
using namespace std;

void ex1();
void ex2();
void ex3();
void ex4();
void ex5();
int main();

#endif // TPPARTIE2_H
